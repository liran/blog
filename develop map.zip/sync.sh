#!/usr/bin/env bash

osmosis --read-apidb host="172.31.85.20" database="openstreetmap" user="root" password="bst123564" validateSchemaVersion="no" --write-pbf  file=bst.pbf &&
osm2pgsql -d gis --create --slim  -G --hstore --tag-transform-script ~/src/openstreetmap-carto/openstreetmap-carto.lua -C 300 --number-processes 1 -S ~/src/openstreetmap-carto/openstreetmap-carto.style bst.pbf
