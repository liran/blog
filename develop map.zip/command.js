osmosis --read-pbf file="Beijing.osm.pbf" --write-pgsimp database="openstreetmap" user="postgres" host="192.168.146.129" validateSchemaVersion=no
osmosis --read-xml Beijing.osm --write-pgsql database="openstreetmap" user="postgres"

osmosis --read-xml file=/home/Beijing.osm --write-pgsimp database="openstreetmap" user="postgres"

osmosis --read-xml file="Beijing.osm" --write-pgsimp validateSchemaVersion=no user="postgres" database="openstreetmap"

osmosis –read-xml file=/home/Beijing.osm –write-pgsimp database="openstreetmap" user="postgres"

osmosis --read-xml file="/home/Beijing.osm" --write-pgsql host="localhost" database="openstreetmap" user="postgres"

osmosis --read-xml file=/home/Beijing.osm --write-apidb host="localhost" database="openstreetmap" user="postgres"

osmosis --read-xml file=map.osm --write-apidb host="192.168.146.129" database="openstreetmap" user="postgres" validateSchemaVersion=no

osmosis --read-xml file="planet.osm" --write-apidb host="x" database="x" user="x" password="x"



osmosis --read-xml file=Beijing.osm --write-apidb host="192.168.146.129" database="openstreetmap" user="postgres" validateSchemaVersion=no

//////
osmosis --read-pbf London.osm.pbf --write-apidb database="openstreetmap" user="root" password="123564" validateSchemaVersion="no"
osmosis --read-pbf china-latest.osm.pbf --write-apidb database="openstreetmap" user="postgres" validateSchemaVersion="no"
osmosis --read-pbf Beijing.osm.pbf --write-apidb host="192.168.146.129" database="openstreetmap" user="postgres" 


osmosis --read-xml file=guanggu.osm --write-apidb database="openstreetmap" user="root" validateSchemaVersion="no" password="bst123564"

sudo -u postgres -i psql -d openstreetmap
ALTER USER root WITH PASSWORD 'bst123564';


bin/osmosis --read-xml file=/tmp/guanggu.osm --write-apidb database="openstreetmap" user="root" validateSchemaVersion="no" password="bst123564"

osmosis --read-apidb host="52.87.160.94" database="openstreetmap" user="root" password="bst123564" validateSchemaVersion="no" --write-xml file=bst.osm
osmosis --read-apidb host="52.87.160.94" database="openstreetmap" user="root" password="bst123564" validateSchemaVersion="no" --write-xml-change --write-xml  file=bst1.osm


osmosis --read-apidb host="172.31.85.20" database="openstreetmap" user="root" password="bst123564" validateSchemaVersion="no" --write-pbf  file=bst.pbf &&
osm2pgsql -d gis --create --slim  -G --hstore --tag-transform-script ~/src/openstreetmap-carto/openstreetmap-carto.lua -C 300 --number-processes 1 -S ~/src/openstreetmap-carto/openstreetmap-carto.style bst.pbf

// shell
osmosis --read-apidb host="52.87.160.94" database="openstreetmap" user="root" password="bst123564" validateSchemaVersion="no" --write-pbf  file=/home/bst.pbf
osm2pgsql -d gis --create --slim  -G --hstore --tag-transform-script /home/openstreetmap-carto/openstreetmap-carto.lua -C 1500 --number-processes 1 -S /home/openstreetmap-carto/openstreetmap-carto.style /home/bst.pbf
rm -f /home/bst.pbf


// --append
osm2pgsql -d gis --append --slim  -G --hstore --tag-transform-script ~/src/openstreetmap-carto/openstreetmap-carto.lua -C 300 --number-processes 1 -S ~/src/openstreetmap-carto/openstreetmap-carto.style bst.pbf